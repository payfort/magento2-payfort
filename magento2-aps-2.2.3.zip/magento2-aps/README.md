## Changelog
`v2.2.3`
- Google chrome session issue resolved
- Apple Pay code simplification

`v2.2.2`
- Namespace change
- Shipping and tax calculation corrections in Apple Pay of Product / Cart pages
- Magento Standards implementation
- Back button click handling after a successful transaction

`v2.2.1`
- Fixed Apple Pay floating point issue

`v2.2.0`
- Single Card Form Config for Installments and Cards

`v2.1.0`
- Install Apple pay in cart page and product page

`v2.0.0`
Release APS Magento2 plugin
