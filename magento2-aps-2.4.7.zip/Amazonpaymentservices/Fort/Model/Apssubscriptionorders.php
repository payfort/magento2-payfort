<?php
namespace Amazonpaymentservices\Fort\Model;

class Apssubscriptionorders extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Amazonpaymentservices\Fort\Model\ResourceModel\Apssubscriptionorders');
    }
}
