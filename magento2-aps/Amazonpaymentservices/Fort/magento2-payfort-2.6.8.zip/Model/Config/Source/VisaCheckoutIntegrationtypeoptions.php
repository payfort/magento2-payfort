<?php
/**
 * Payment Config Source Visa Checkout Integraton Type Options
 * php version 8.2.*
 *
 * @category Amazonpaymentservices
 * @package  Amazonpaymentservices_Fort
 * @author   Amazonpaymentservices <email@example.com>
 * @license  GNU / GPL v3
 * @version  GIT: @1.0.0@
 * @link     Amazonpaymentservices
 **/
namespace Amazonpaymentservices\Fort\Model\Config\Source;

/**
 * Payment Config Source Visa Checkout Integraton Type Options
 * php version 8.2.*
 *
 * @author   Amazonpaymentservices <email@example.com>
 * @license  GNU / GPL v3
 * @version  GIT: @1.0.0@
 * @link     Amazonpaymentservices
 **/
class VisaCheckoutIntegrationtypeoptions implements \Magento\Framework\Option\ArrayInterface
{
    const REDIRECTION  = "redirection";

    const HOSTED = "hosted";
    
    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::REDIRECTION,
                'label' => __('Redirection'),
            ],
            [
                'value' => self::HOSTED,
                'label' => __('Hosted Checkout')
            ]
        ];
    }
}
